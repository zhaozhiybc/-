import sqlite3
import os


class Database:
    def __init__(self):
        self.db_file = 'flower_shop.sqlite'
        self._initialize_db()

    def _get_connection(self):
        """获取新的数据库连接"""
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize_db(self):
        """初始化数据库"""
        if not os.path.exists(self.db_file):
            self.create_tables()

    def create_tables(self):
        """创建数据库表"""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # 用户表
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL DEFAULT 'staff'
            );
            """)

            # 花卉表
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS flowers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100) NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                stock INTEGER NOT NULL DEFAULT 0,
                description TEXT,
                image_url VARCHAR(255) DEFAULT 'default.jpg'
            );
            """)

            # 订单表
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name VARCHAR(255) NOT NULL,
                customer_phone VARCHAR(50) NOT NULL,
                delivery_address TEXT NOT NULL,
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                delivery_date TIMESTAMP,
                status VARCHAR(50) DEFAULT 'pending',
                total_amount DECIMAL(10,2) NOT NULL
            );
            """)

            # 订单详情表
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                flower_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price DECIMAL(10,2) NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                FOREIGN KEY (flower_id) REFERENCES flowers(id)
            );
            """)

            conn.commit()

    # 用户操作
    def get_user_count(self):
        """获取用户数量"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM users")
            return cursor.fetchone()[0]

    def create_user(self, username, password, role='staff'):
        """创建用户"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO users(username, password, role) VALUES (?, ?, ?)",
                (username, password, role)
            )
            conn.commit()

    def get_user_by_username(self, username):
        """根据用户名获取用户"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username=?", (username,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def authenticate_user(self, username, password):
        """验证用户"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM users WHERE username=? AND password=?",
                (username, password)
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    # 花卉操作
    def add_flower(self, name, category, price, stock, description, image_url):
        """添加花卉"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO flowers(name, category, price, stock, description, image_url) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (name, category, price, stock, description, image_url)
            )
            conn.commit()

    def get_all_flowers(self):
        """获取所有花卉"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM flowers ORDER BY name")
            return [dict(row) for row in cursor.fetchall()]

    def get_flower_by_id(self, flower_id):
        """根据ID获取花卉"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM flowers WHERE id=?", (flower_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def update_flower_stock(self, flower_id, quantity):
        """更新花卉库存"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE flowers SET stock = stock - ? WHERE id=?",
                (quantity, flower_id)
            )
            conn.commit()

    def delete_flower(self, flower_id):
        """删除花卉"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM flowers WHERE id=?", (flower_id,))
            conn.commit()

    # 订单操作
    def create_order(self, customer_name, customer_phone, delivery_address, delivery_date, total_amount):
        """创建订单"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO orders(customer_name, customer_phone, delivery_address, 
                   delivery_date, total_amount) 
                   VALUES (?, ?, ?, ?, ?)""",
                (customer_name, customer_phone, delivery_address, delivery_date, total_amount)
            )
            conn.commit()
            return cursor.lastrowid

    def add_order_item(self, order_id, flower_id, quantity, unit_price):
        """添加订单项"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO order_items(order_id, flower_id, quantity, unit_price) 
                   VALUES (?, ?, ?, ?)""",
                (order_id, flower_id, quantity, unit_price)
            )
            conn.commit()

    def get_all_orders(self):
        """获取所有订单"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM orders ORDER BY order_date DESC")
            return [dict(row) for row in cursor.fetchall()]

    def get_order_details(self, order_id):
        """获取订单详情"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM orders WHERE id=?", (order_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_order_items(self, order_id):
        """获取订单项"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT oi.*, f.name as flower_name 
                   FROM order_items oi
                   JOIN flowers f ON oi.flower_id = f.id
                   WHERE oi.order_id=?""",
                (order_id,)
            )
            return [dict(row) for row in cursor.fetchall()]

    def update_order_status(self, order_id, status):
        """更新订单状态"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE orders SET status=? WHERE id=?",
                (status, order_id)
            )
            conn.commit()