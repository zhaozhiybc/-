from flask import Flask, render_template, request, session, redirect, url_for, flash, jsonify
from db import Database
from functools import wraps
import os

app = Flask(__name__)
app.secret_key = 'flower_shop_secret_key'

# 初始化数据库
db = Database()

# 确保静态文件目录存在
os.makedirs('static/images', exist_ok=True)

# 添加一些测试数据
if not db.get_user_count():
    db.create_user('admin', 'admin123', 'admin')
    db.create_user('staff1', 'staff123', 'staff')

    # 添加花卉数据
    db.add_flower('红玫瑰', '玫瑰', 12.99, 50, '经典红玫瑰，象征热情与爱情', 'rose.jpg')
    db.add_flower('白百合', '百合', 9.99, 30, '纯洁的白百合，象征纯洁与高贵', 'lily.jpg')
    db.add_flower('粉康乃馨', '康乃馨', 8.50, 40, '温馨的粉康乃馨，适合送给长辈', 'carnation.jpg')
    db.add_flower('黄郁金香', '郁金香', 10.25, 35, '明亮的黄郁金香，象征快乐与友谊', 'tulip.jpg')


def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return func(*args, **kwargs)

    return wrapper


def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'role' not in session or session['role'] != 'admin':
            flash('需要管理员权限')
            return redirect(url_for('index'))
        return func(*args, **kwargs)

    return wrapper


@app.route('/')
@login_required
def index():
    flowers = db.get_all_flowers()
    orders = db.get_all_orders()

    # 计算今日订单数量（简化处理）
    today_orders = len([o for o in orders if o['order_date'].startswith('2025-06-04')])

    return render_template('index.html', flowers=flowers, today_orders=today_orders)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash('请输入用户名和密码')
            return render_template('login.html')

        user = db.authenticate_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            return redirect(url_for('index'))
        flash('用户名或密码错误')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = 'staff'  # 新注册用户默认为员工角色

        # 验证输入
        errors = []
        if not username:
            errors.append('请输入用户名')
        if not password:
            errors.append('请输入密码')
        if password != confirm_password:
            errors.append('两次输入的密码不一致')
        if db.get_user_by_username(username):
            errors.append('用户名已存在')

        if errors:
            for error in errors:
                flash(error)
            return render_template('register.html')

        # 创建用户
        db.create_user(username, password, role)
        flash('注册成功，请登录')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/flowers')
@login_required
def flower_list():
    flowers = db.get_all_flowers()
    return render_template('flower_list.html', flowers=flowers)


@app.route('/flowers/add', methods=['GET', 'POST'])
@admin_required
def add_flower():
    if request.method == 'POST':
        name = request.form.get('name')
        category = request.form.get('category')
        price = request.form.get('price')
        stock = request.form.get('stock')
        description = request.form.get('description')
        image_url = request.form.get('image_url', 'default.jpg')

        # 验证输入
        errors = []
        if not name: errors.append('请输入花卉名称')
        if not category: errors.append('请选择花卉类别')
        if not price or not price.replace('.', '', 1).isdigit():
            errors.append('请输入有效的价格')
        if not stock or not stock.isdigit():
            errors.append('请输入有效的库存数量')

        if errors:
            for error in errors:
                flash(error)
            return render_template('add_flower.html')

        # 添加花卉
        db.add_flower(name, category, float(price), int(stock), description, image_url)
        flash('花卉添加成功')
        return redirect(url_for('flower_list'))

    return render_template('add_flower.html')


@app.route('/flowers/<int:flower_id>/delete', methods=['POST'])
@admin_required
def delete_flower(flower_id):
    db.delete_flower(flower_id)
    flash('花卉删除成功')
    return redirect(url_for('flower_list'))


@app.route('/orders')
@login_required
def order_list():
    orders = db.get_all_orders()
    return render_template('order_list.html', orders=orders)


@app.route('/orders/create', methods=['GET', 'POST'])
@login_required
def create_order():
    if request.method == 'POST':
        customer_name = request.form.get('customer_name')
        customer_phone = request.form.get('customer_phone')
        delivery_address = request.form.get('delivery_address')
        delivery_date = request.form.get('delivery_date')
        flower_ids = request.form.getlist('flower_ids')

        # 验证输入
        errors = []
        if not customer_name: errors.append('请输入客户姓名')
        if not customer_phone: errors.append('请输入联系电话')
        if not delivery_address: errors.append('请输入配送地址')
        if not delivery_date: errors.append('请选择配送日期')
        if not flower_ids: errors.append('请选择至少一种花卉')

        if errors:
            for error in errors:
                flash(error)
            flowers = db.get_all_flowers()
            return render_template('create_order.html', flowers=flowers)

        # 计算总金额和订单详情
        total_amount = 0
        order_items = []

        for flower_id in flower_ids:
            quantity = int(request.form.get(f'quantity-{flower_id}', 1))
            flower = db.get_flower_by_id(flower_id)
            if flower:
                unit_price = flower['price']
                total_amount += unit_price * quantity
                order_items.append({
                    'flower_id': flower_id,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'flower_name': flower['name']
                })

        # 创建订单
        order_id = db.create_order(
            customer_name, customer_phone,
            delivery_address, delivery_date,
            total_amount
        )

        # 添加订单项
        for item in order_items:
            db.add_order_item(
                order_id, item['flower_id'],
                item['quantity'], item['unit_price']
            )

            # 更新库存
            db.update_flower_stock(item['flower_id'], item['quantity'])

        flash('订单创建成功')
        return redirect(url_for('order_details', order_id=order_id))

    flowers = db.get_all_flowers()
    return render_template('create_order.html', flowers=flowers)


@app.route('/orders/<int:order_id>')
@login_required
def order_details(order_id):
    order = db.get_order_details(order_id)
    if not order:
        flash('订单不存在')
        return redirect(url_for('order_list'))

    order_items = db.get_order_items(order_id)
    return render_template('order_details.html', order=order, order_items=order_items)


@app.route('/orders/<int:order_id>/update_status', methods=['POST'])
@login_required
def update_order_status(order_id):
    new_status = request.form.get('status')
    if new_status in ['pending', 'processing', 'completed', 'cancelled']:
        db.update_order_status(order_id, new_status)
        flash('订单状态已更新')
    else:
        flash('无效的订单状态')

    return redirect(url_for('order_details', order_id=order_id))


if __name__ == '__main__':
    # 确保数据库表已创建
    db.create_tables()

    # 运行应用
    app.run(debug=True, port=5001)